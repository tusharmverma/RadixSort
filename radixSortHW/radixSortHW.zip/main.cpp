/**
 * @file    main.cpp
 * @brief   Sorting elements based on radix sort
 *
 * @remarks
 *      Course:        Computer Science
 *      Assignment #:  Radix Sort
 *      Due Date:      10/10/2017
 *      Instructor:    Dr. E.T Hammerand
 *
 * @author        Tushar Verma
 * @date          10/10/2017
 */
#include <iostream>
#include "radixSort.h"
#include <chrono>
using namespace std;


int main()
{
    radixSort s;
    int base;
    cout <<"Enter the Base: ";
    cin>> base;
    s.getdata();
    s.radixsort(base);
    s.showdata();
    return 0;
}
